# 说明
#### GPU与软件版本
||版本号|
|:---:|:---:|
|GPU型号| RTX 5060 |
|NVIDIA驱动版本|610.71|
|CUDA Toolkit版本| release 13.0|
|SGLang|0.5.14|
|Ray|2.56.0|
|Qwen|3-06B|  
|python|3.12.14|
#### 安装方法
根据官网上的命令行下载
#### target1说明
- **启动sglang服务.txt**,内含启动服务的命令行和一系列参数，重点在**max_prefill_tokens 32768**,不加参数有时候无法运行test脚本
- **test.txt**,内含执行任务一的代码


